﻿using Microsoft.EntityFrameworkCore;
using NovoSupermerdado.Models;

namespace NovoSupermerdado.Data
{
    public class MercadoContext : DbContext
    {
        public MercadoContext(DbContextOptions<MercadoContext> options) : base(options) { }

        public DbSet<Categoria> Categorias { get; set; }
        public DbSet<Produto> Produto { get; set; }
        public DbSet<Clientes> Clientes { get; set; }
        public DbSet<Fornecedor> Fornecedor { get; set; }
        public DbSet<Vendas> Vendas { get; set; }
        public DbSet<Compras> Compras { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Categoria>().ToTable("tbCategoria");
            modelBuilder.Entity<Produto>().ToTable("tbProduto");
            modelBuilder.Entity<Fornecedor>().ToTable("tbFornecedor");
            modelBuilder.Entity<Clientes>().ToTable("tbClientes");
            modelBuilder.Entity<Vendas>().ToTable("tbVendas");
            modelBuilder.Entity<Compras>().ToTable("tbCompras");
        }


        public DbSet<NovoSupermerdado.Models.Vendas> Vendas_1 { get; set; } = default!;



    }
}
