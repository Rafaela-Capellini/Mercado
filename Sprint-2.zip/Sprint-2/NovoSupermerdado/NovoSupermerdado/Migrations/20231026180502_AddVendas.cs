﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NovoSupermerdado.Migrations
{
    /// <inheritdoc />
    public partial class AddVendas : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbVendasCad");

            migrationBuilder.CreateTable(
                name: "tbVendas",
                columns: table => new
                {
                    VendasId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Cliente = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Data = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ProdutoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbVendas", x => x.VendasId);
                    table.ForeignKey(
                        name: "FK_tbVendas_tbProduto_ProdutoId",
                        column: x => x.ProdutoId,
                        principalTable: "tbProduto",
                        principalColumn: "ProdutoId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_tbVendas_ProdutoId",
                table: "tbVendas",
                column: "ProdutoId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbVendas");

            migrationBuilder.CreateTable(
                name: "tbVendasCad",
                columns: table => new
                {
                    VendasCadId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Cliente = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Data = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Produto = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbVendasCad", x => x.VendasCadId);
                });
        }
    }
}
