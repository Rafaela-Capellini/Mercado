﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace NovoSupermerdado.Controllers
{
    public class RelatoriosController : Controller
    {

        public IActionResult RelatProd()
        {
            return View();
        }

        public IActionResult RelatMov()
        {
            return View();
        }

    }
}
