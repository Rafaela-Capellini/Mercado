﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NovoSupermerdado.Data;
using NovoSupermerdado.Models;

namespace NovoSupermerdado.Controllers
{


    public class VendasController : Controller
    {
        private readonly MercadoContext _context;

        public VendasController(MercadoContext context)
        {
            _context = context;
        }

        // GET: Vendas
        [Authorize(Roles = "Admin,Operador")]
        public async Task<IActionResult> Index()
        {
            var mercadoContext = _context.Vendas_1.Include(v => v.Produto);
            return View(await mercadoContext.ToListAsync());
        }

        // GET: Vendas/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null || _context.Vendas_1 == null)
            {
                return NotFound();
            }

            var vendas = await _context.Vendas_1
                .Include(v => v.Produto)
                .FirstOrDefaultAsync(m => m.VendasId == id);
            if (vendas == null)
            {
                return NotFound();
            }

            return View(vendas);
        }

        // GET: Vendas/Create
        public IActionResult Create()
        {
            ViewData["ProdutoId"] = new SelectList(_context.Produto, "ProdutoId", "ProdutoId");
            return View();
        }

        // POST: Vendas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VendasId,Cliente,Data,ProdutoId")] Vendas vendas)
        {
            if (ModelState.IsValid)
            {
                vendas.VendasId = Guid.NewGuid();
                _context.Add(vendas);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProdutoId"] = new SelectList(_context.Produto, "ProdutoId", "ProdutoId", vendas.ProdutoId);
            return View(vendas);
        }

        // GET: Vendas/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null || _context.Vendas_1 == null)
            {
                return NotFound();
            }

            var vendas = await _context.Vendas_1.FindAsync(id);
            if (vendas == null)
            {
                return NotFound();
            }
            ViewData["ProdutoId"] = new SelectList(_context.Produto, "ProdutoId", "ProdutoId", vendas.ProdutoId);
            return View(vendas);
        }

        // POST: Vendas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("VendasId,Cliente,Data,ProdutoId")] Vendas vendas)
        {
            if (id != vendas.VendasId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(vendas);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VendasExists(vendas.VendasId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProdutoId"] = new SelectList(_context.Produto, "ProdutoId", "ProdutoId", vendas.ProdutoId);
            return View(vendas);
        }

        // GET: Vendas/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null || _context.Vendas_1 == null)
            {
                return NotFound();
            }

            var vendas = await _context.Vendas_1
                .Include(v => v.Produto)
                .FirstOrDefaultAsync(m => m.VendasId == id);
            if (vendas == null)
            {
                return NotFound();
            }

            return View(vendas);
        }

        // POST: Vendas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            if (_context.Vendas_1 == null)
            {
                return Problem("Entity set 'MercadoContext.Vendas_1'  is null.");
            }
            var vendas = await _context.Vendas_1.FindAsync(id);
            if (vendas != null)
            {
                _context.Vendas_1.Remove(vendas);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool VendasExists(Guid id)
        {
          return (_context.Vendas_1?.Any(e => e.VendasId == id)).GetValueOrDefault();
        }
    }
}
