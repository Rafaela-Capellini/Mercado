﻿namespace NovoSupermerdado.Models
{
    public class Fornecedor
    {
        public Guid FornecedorId { get; set; }

        public string Nome { get; set; }   
        
        public string Cnpj { get; set;}

        public DateTime DataCadastro { get; set; }
    }
}
