﻿namespace NovoSupermerdado.Models
{
    public class Vendas
    {
        public Guid VendasId { get; set; }
        public string Cliente { get; set; }
        public DateTime Data { get; set;}
        public Guid ProdutoId { get; set; }
        public Produto? Produto { get; set; }
    }
}
