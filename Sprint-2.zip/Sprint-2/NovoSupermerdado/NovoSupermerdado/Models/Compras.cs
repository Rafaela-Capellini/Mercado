﻿namespace NovoSupermerdado.Models
{
    public class Compras
    {
        public Guid ComprasId { get; set; }
        public DateTime Data { get; set; }
        public Guid FornecedorId { get; set; }
        public Fornecedor? fornecedor { get; set; }
        public Guid ProdutoId { get; set; }
        public Produto? produto { get; set; }
        public int Estoque { get; set; }

    }
}
