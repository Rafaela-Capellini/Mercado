﻿namespace NovoSupermerdado.Models
{
    public class Clientes
    {
        public Guid ClientesId { get; set; }
        public string Nome { get; set; }
        public int Telefone { get; set; }
        public string Cpf { get; set; } 
        public string email { get; set; }
        public string endereco { get; set; }
        public DateTime Nascimento { get; set; }
    }
}
